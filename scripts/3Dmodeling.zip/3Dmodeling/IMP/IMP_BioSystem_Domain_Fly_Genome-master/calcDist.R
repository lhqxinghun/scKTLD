rm(list = ls())


coord <- read.table("/media/biology/datadisk/liuerhu/scTAD/simulatedata/K562-070/outputs_test_800/chr8_2500_2999/models/model.6.xyz", sep = "\t")[, 3:5]

coord <- apply(coord, 2, as.numeric)

dist <- c()
for (i in 1:nrow(coord)) {
  for (j in i:nrow(coord)) {
    dist <- c(dist, sqrt(sum((coord[i, ]-coord[j, ])^2)))
  }
}

cdf <- c()
x <- seq(0, max(dist)*1.03, max(dist)/50)
for(i in 1:length(x))
{
  cdf <- c(cdf, sum(dist<x[i]))
}
cdf <- cdf/length(dist)

plot(x, cdf, type = "l", lwd = 2)
