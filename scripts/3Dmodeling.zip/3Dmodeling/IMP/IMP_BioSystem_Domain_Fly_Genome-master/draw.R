rm(list = ls())

mat <- as.matrix(read.table("/media/biology/datadisk/liuerhu/scTAD/simulatedata/K562-070/outputs_test_800/chr8_2500_2999/models/ensemble/model.1.mat"))

library(gplots)

heatmap.2(mat, Rowv=FALSE, col = colorpanel(128, "white", "red"), symm = TRUE, dendrogram = "none", trace = "none", labRow = FALSE, labCol = FALSE, density.info = "none", margins = c(0.1, 0.1), key = FALSE, lmat = rbind(c(1,4), c(3,2)), lhei = c(7,1), lwid = c(7,1))

mat2 <- as.matrix(read.table("/media/biology/datadisk/liuerhu/scTAD/simulatedata/K562-070/outputs_test_800/chr8_10000_10499/models/ensemble/model.500.mat"))
heatmap.2(mat2, Rowv=FALSE, col = colorpanel(128, "white", "red"), symm = TRUE, dendrogram = "none", trace = "none", labRow = FALSE, labCol = FALSE, density.info = "none", margins = c(0.1, 0.1), key = FALSE, lmat = rbind(c(1,4), c(3,2)), lhei = c(7,1), lwid = c(7,1))